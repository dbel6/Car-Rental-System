/*
    Student Name : 		Daniel Belov
    Student Id Number : CO0306133
    Date :				12/2//2026
    Purpose : 			To complete javascript part of Add Company screen
*/

function check()
//confirms if a user wants to add a company when user submits form
{
    if (!confirm("Are you sure you want to add company?"))
    //displays confirmation message asking if the user wants to add the company
    {
        return false;
        //blocks the company from being added to the database
    }
    else
    //runs if user clicks confirm
    {
        return true;
        //adds company to the database
    }
}