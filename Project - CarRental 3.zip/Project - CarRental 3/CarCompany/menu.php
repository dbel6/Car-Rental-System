<!--
    Student Name : 		Daniel Belov
    Student Id Number : CO0306133
    Date :				5/3/2026
    Purpose : 			To complete menu part of Company screen
-->

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="Style.css">
    <!--Linked (external) style sheet with classes including form and input which styles the form for better presentation-->
</head>
<body>

    <div class="form">
    <!--Displays a menu where user can select buttons-->
    <!--Div (division) causes the text it encloses to start on a new line-->

    <div class="menu">
    <!--Displays a menu area where user can select buttons-->
    <!--Div (division) causes the text it encloses to start on a new line-->

    <img src="CompanyLogo.png" height="50" width="50">
    <!--Company Logo image that fits in the menu-->

    <a href="menu.php">Home</a>
    <!--Home button--> 
    <a href="AddNewCarCompany.html.php">Add Company</a>
    <!--Add Company button-->
    <a href="DeleteNewCarCompany.php">Delete Company</a>
    <!--Delete Company button-->
    <a href="AmendViewCarCompany.html.php">Amend/View Company</a>
    <!--Update Company button-->
    <a href="Rentals.php">Rentals</a>
    <!--Rentals button--> 

</div>
</div>
</body>
</html>