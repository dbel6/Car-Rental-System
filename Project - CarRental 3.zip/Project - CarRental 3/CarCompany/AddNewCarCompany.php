<!--
    Student Name : 		Daniel Belov
    Student Id Number : CO0306133
    Date :				12/2/2026
    Purpose : 			To complete php part of Add Company screen
-->

<?php
/*Creates a space allowing for calculating user input*/
include 'db.inc.php';
//Enables content from the file "db.inc.php" to be included in this file
date_default_timezone_set("UTC");
/*Gets the default date time*/
echo "The details sent down are: <br>";
//Outputs details that are sent down

echo "Name is : " . $_POST['Name'] . "<br>";
//Outputs the inputted name

echo "Address is : " . $_POST['Address'] . "<br>";
//Outputs the inputted address

echo "Phone is : " . $_POST['Phone'] . "<br>";
//Outputs the inputted phone number

echo "Website is : " . $_POST['Website'] . "<br>";
//Outputs the inputted website

echo "Email is : " . $_POST['Email'] . "<br>";
//Outputs the inputted email

echo "Credit Limit is : " . $_POST['CreditLimit'] . "<br>";
//Outputs the inputted credit limit

echo "Amount Owed is : " . 0 . "<br>";
//Outputs the amount owed

echo "Total Rentals is : " . 0 . "<br>";
//Outputs the total rentals

echo "Blacklist Flag is : " . 'N' . "<br>";
//Outputs the blacklist flag

echo "Number times blacklisted is : " . 0 . "<br>";
//Outputs the number of times blacklisted

$sql = "INSERT INTO Company (Name,Address,Phone,Website,Email,CreditLimit,AmountOwed,TotalRentals,BlacklistFlag,NumTimesBlacklisted) VALUES ('$_POST[Name]','$_POST[Address]','$_POST[Phone]','$_POST[Website]','$_POST[Email]','$_POST[CreditLimit]', 0, 0, 'N', 0)";
//Inserts the name, address, phone number, website, email, credit limit, amount owed, total rentals, blacklist flag and number of times blacklisted into the Company database

if (!mysqli_query($con,$sql))
//Checks if theres an error in the sql
{
    die ("An Error in the SQL Query: " . mysqli_error($con));
    //Outputs an error message if theres an error in the sql
}
echo "<br>A company has been added for " . $_POST['Name'] . ".";
//Outputs a message confirming the company has been added for the inputted name

echo "<br>The new company id for " . $_POST['Name'] . " is " . mysqli_insert_id($con);
//Outputs the newly assigned company id

mysqli_close($con);
//Closes the sql database

?>
<form action="AddNewCarCompany.html.php" method="POST">
<!--Creates a form where user can input information which gets processed through a html file with method post to collect information-->
<br>
<!--Creates a single line break-->
<input type="submit" value="Return to Add Company Page"/>
<!--Displays submit button where user can return to the add company screen-->
</form>