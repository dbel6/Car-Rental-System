<!--
    Student Name : 		Daniel Belov
    Student Id Number : CO0306133
    Date :				12/2/2026
    Purpose : 			To complete html php part of Add Company screen
-->

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="Style.css">
    <!--Link to css file which styles the form for better presentation-->
    <title>Add New Company Screen</title>
    <!--Title of exercise-->
    <script src="AddNewCarCompany.js"></script>
    <!--Script used to embed Javascript-->
</head>
<body>

<?php
//Creates a space allowing for calculating user input
include 'menu.php';
//menu connection
?>

<div class="title">
<!--Displays a title for the form-->
<!--Div (division) causes the text it encloses to start on a new line-->
<h1>Add Company</h1>
<!--Add Company title-->
</div>
    
<form action="AddNewCarCompany.php" method="post" onsubmit="return check()" >
<!--Form where user can input information which gets processed through a php file with method post to collect information-->
<!--Input gets sent to a function which ensures if the user wants to confirm submission and returns true or false-->

<p><label for="Name">Name</label>
<!--Name title-->
<br>
<!--Single line break-->
<input type="text" name="Name" id="Name" placeholder="Name" autocomplete="off" pattern="[A-Z]{2}[\s]{1}[a-z]+" minlength="2" maxlength="30" title="Name must only contain alphabetic characters and spaces" required/>
<!--Name text box-->
<!--Required attribute ensures field must contain a value when the form is submitted-->
<!--Placeholder attribute gives a faint text over inputbox displaying what input is expected-->
<!--Autocomplete attribute completes text automatically which is set to off-->
<!--This pattern ensures only text and spaces are inputted with a minimum limit of 2 and a maximum limit of 30-->
<!--Title attribute ensures a message is displayed if the user hovers over the field, or if the pattern isn't correct-->
</p>
<br>
<!--Single line break-->
<p><label for="Address">Address</label>
<!--Address title-->
<br>
<!--Single line break-->
<textarea name="Address" id="Address" rows="5" cols="35" placeholder="Address" pattern="[A-Za-z0-9\s]+" maxlength="50" title="Address must only contain text, numbers and spaces" required></textarea>
<!--Address text area box of size 5 rows and 35 columns-->
<!--Required attribute ensures field must contain a value when the form is submitted-->
<!--Placeholder attribute gives a faint text over inputbox displaying what input is expected-->
<!--This pattern ensures only text, numbers and spaces are inputted with a limit of 50-->
<!--Title attribute ensures a message is displayed if the user hovers over the field, or if the pattern isn't correct-->
</p>
<br><br><br><br>
<!--4 line breaks-->
<p><label for="Phone">Phone Number</label>
<!--Phone number title-->
<br>
<!--Single line break-->
<input type="text" name="Phone" id="Phone" placeholder="Phone Number" pattern="[0-9\(\)\-\+\s]+" maxlength="18" title="Phone number must only contain digits, brackets, dashes, pluses and spaces" required/>
<!--Phone text box-->
<!--Required attribute ensures field must contain a value when the form is submitted-->
<!--Placeholder attribute gives a faint text over inputbox displaying what input is expected-->
<!--This pattern ensures only digits, brackets, dashes, pluses and spaces are inputted with a limit of 18-->
<!--Title attribute ensures a message is displayed if the user hovers over the field, or if the pattern isn't correct-->
</p>
<br>
<!--Single line break-->
<p><label for="Website">Website</label>
<!--Website title-->
<br>
<!--Single line break-->
<input type="url" name="Website" id="Website" placeholder="Website" pattern="[A-Za-z0-9\:\/\.]+" maxlength="30" title="Website must be a valid url" required/>
<!--Website url box-->
<!--Required attribute ensures field must contain a value when the form is submitted-->
<!--Placeholder attribute gives a faint text over inputbox displaying what input is expected-->
<!--This pattern ensures only alphabetic characters, digits, colon, forward and dot are inputted with a limit of 30-->
<!--Title attribute ensures a message is displayed if the user hovers over the field, or if the pattern isn't correct-->
</p>
<br>
<!--Single line break-->
<p><label for="Email">Email Address</label>
<!--Email address title-->
<br>
<!--Single line break-->
<input type="email" name="Email" id="Email" placeholder="Email Address" pattern="[A-Za-z0-9\@\.]+" maxlength="30" title="Email must be a valid email address" required/>
<!--Email email box-->
<!--Required attribute ensures field must contain a value when the form is submitted-->
<!--Placeholder attribute gives a faint text over inputbox displaying what input is expected-->
<!--This pattern ensures only alphabetic characters, digits, at symbol and dot are inputted with a limit of 30-->
<!--Title attribute ensures a message is displayed if the user hovers over the field, or if the pattern isn't correct-->
</p>
<br>
<!--Single line break-->
<p><label for="CreditLimit">Credit Limit</label>
<!--Credit limit title-->
<br>
<!--Single line break-->
<input type="number" name="CreditLimit" id="CreditLimit" placeholder="Credit Limit" pattern="[0-9]+" min="0" required/>
<!--CreditLimit number box-->
<!--Required attribute ensures field must contain a value when the form is submitted-->
<!--Placeholder attribute gives a faint text over inputbox displaying what input is expected-->
<!--This pattern ensures only digits are inputted with a minimum limit of 0-->
</p>
<br>
<!--Single line break-->
<input type="submit" value="Submit"/>
<!--Submit button where user can submit all information provided-->
<input type="reset" value="Clear"/>
<!--Reset button where user can clear all information provided-->
</form>
</body>
</html>